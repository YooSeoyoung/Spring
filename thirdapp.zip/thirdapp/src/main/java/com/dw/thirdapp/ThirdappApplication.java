package com.dw.thirdapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThirdappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThirdappApplication.class, args);
	}

}
